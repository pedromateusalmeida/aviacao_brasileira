
-   __Databricks Certified Associate Developer for Apache Spark 3.0__<br />
    Databricks<br />
    https://credentials.databricks.com/d1329d21-2d85-40b9-933f-a8aeec2eb387<br />
    Códifo da credencial: 72876551<br />

---

-   __Databricks Lakehouse Fundamentals__<br />
    Databricks<br />
    https://credentials.databricks.com/5d52d338-d78b-45b0-8b4b-b3bb749a44b0<br />

---

-   __Platform Administrator__<br />
    Databricks<br />
    https://credentials.databricks.com/86f903be-f420-4b8c-a223-b61cf56290af<br />

--- 
    
-   __Google Analytics Individual Qualification__<br />
    Código da credencial: 53851809<br />


--- 
    
-    __Google Ad Manager__<br />
    Código da credencial: 53845398<br />


--- 
    
-   __Big Data Fundamentos 2.0__<br />
    Data Science Academy<br />
    Código da credencial: 5daa387e5e4cde68588b457a<br />
    https://mycourse.app/iHiu<br />


--- 
    
-   __Python Fundamentos para Análise de Dados__<br />
    Data Science Academy<br />
    Código da credencial: 5cdad92a5e4cde512d8b4586<br />
    https://mycourse.app/796tWc2MBaRbqiFe7<br />
    

--- 
    
-   __Big Data Analytics com R e Microsoft Azure Machine Learning__<br />
    Data Science Academy<br />
    Código da credencial: 5ca623015e4cdefe618b456a<br />
    https://mycourse.app/bv2Nwx33AYETwyCq5<br />

--- 
    
-   __Microsoft Power BI para Data Science__<br />
    Data Science Academy<br />
    Código da credencial: 5bfe09105e4cde8d0e8b4572<br />
    https://goo.gl/CycLUQ<br />

--- 
    
-   __SQL Completo__<br />
    Softblue Cursos Online<br />
    Código da credencial: 3487502CB310<br />
    http://soft.blue/certificado/3487502CB310<br />
      
--- 

-   __Curso de estatística aplicada a Ciências Sociais__<br />
    UFMG<br />
    Carga Hóraria: 30 Horas<br />  
--- 

-   __DESVENDANDO A INDÚSTRIA 4.0__<br />
    Senai São Paulo<br />

--- 

-   __Análise Espacial Aplicada à Pesquisa Social__<br />
    UnB -  Brasilia/DF<br />
    Carga Hóraria: 10 Horas<br /> 

--- 

-   __Curso Dilemas da Cidadania no Brasil__<br />
    Escola do Legislativo<br />
    Assembleia Legislativa do Estado de Minas Gerais - ALEMG<br />

## Apresentações de trabalho


CANCADO, H. O. R. ; ALMEIDA, P. M. M. . O que dá mais voto? Uma análise descritiva dos gastos eleitorais de candidatos a vereador em Belo Horizonte. 2018. (Apresentação de Trabalho/Congresso).<br />


ALMEIDA, P. M. M.. Reforma Política na Perspectiva dos Parlamentares Brasileiros. 2015. (Apresentação de Trabalho/Congresso).<br />


ALMEIDA, P. M. M.. Analisando o impacto das resoluções das Conferências Estaduais de Política para Mulheres (2009, 2011) na produção legislativa da Assembléia Legislativa de Minas Gerais. 2014. (Apresentação de Trabalho/Congresso).<br />


ALMEIDA, P. M. M.; DIOGO, F. F. ; FARIA, C. F. . PERFIL DE OPINIÃO DAS/DOS PARTICIPANTES DAS CONFERÊNCIAS DE SAÚDE E ASSISTÊNCIA SOCIAL. 2013. (Apresentação de Trabalho/Outra).<br />


DIOGO, F. F. ; ALMEIDA, P. M. M. ; FARIA, C. F. . PERFIL E OPINIÃO DOS PARTICIPANTES DAS CONFERÊNCIAS DE POLÍTICA PARA AS MULHERES E ASSISTÊNCIA SOCIAL: DO LOCAL AO ESTADUAL. 2013. (Apresentação de Trabalho/Outra).<br />


ALMEIDA, P. M. M.; RIBEIRO, N. S. . Em comum a luta contra a precariedade de trabalho: uma discussão dos conceitos e ajustes neoliberais nos movimentos de trabalhadores da Polícia Militar (BA) e dos professores do estado (MG). 2012. (Apresentação de Trabalho/Outra).<br />


ALMEIDA, P. M. M.; RIBEIRO, N. S. . Educação em questão, o conceito de transdisciplinaridade e a aplicabilidade deste no ensino de América Latina. 2012. (Apresentação de Trabalho/Outra).<br />


ALMEIDA, P. M. M.; PINTO, E. R. F. . Controle Ministerial: Uma Nova Abordagem Sobre as Relações Entre Executivo e Legislativo. 2011. (Apresentação de Trabalho/Simpósio).<br />


SILVA, B. L. ; SOUSA, D. T. ; ALVES, D. A. ; REGHIM, M. S. ; ALMEIDA, P. M. M. ; MARIA, M. T. C. ; MARTINS, R. B. ; CAMPOS, M. L. ; MARES, E. S. ; RODRIGUES, L. A. . O Projeto Café Filosófico: Intelectuais, Arte e Vida Pública. 2011. (Apresentação de Trabalho/Simpósio).<br />

Simpósio de Integração Acadêmica UFV.Controle Ministerial: Uma nova abordagem sobre as Relações entre Executivo e Legislativo no Brasil. 2011. (Simpósio).<br />

--- 

## Publicações

TEM SAÍDA? ENSAIOS CRÍTICOS SOBRE O BRASIL<br />
Grupo de Pesquisa Opinião Publica · 2 de abr de 2018<br />
https://issuu.com/grupoopiniaopublica/docs/png2pdf<br />